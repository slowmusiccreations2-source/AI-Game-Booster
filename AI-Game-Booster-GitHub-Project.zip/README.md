# AI Game Booster (Demo)

A tiny native Android Kotlin sample project.

## Build APK using GitHub Actions

1. Create a GitHub repository.
2. Upload the contents of this project ZIP (not the ZIP itself).
3. Push/commit the files to the `main` branch.
4. Open the repository's **Actions** tab.
5. Select **Build Android APK** and run it, or wait for the automatic push build.
6. Open the completed workflow run and download the `AI-Game-Booster-debug` artifact.
7. Extract the downloaded artifact ZIP to get `app-debug.apk`.

## Important limitations

This is a demonstration app. Its Gaming Mode button changes the app's own mode indicator, and the RAM panel reads Android's memory information. It does not overclock CPU/GPU, modify Free Fire, kill other apps, or guarantee higher FPS. Those actions are restricted or unavailable to ordinary Android apps without special system privileges.

## Project details

- Kotlin
- Android Gradle Plugin 8.6.1
- Gradle 8.7
- JDK 17
- Minimum Android API 23
