package com.example.aigamebooster

import android.app.Activity
import android.app.ActivityManager
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var ramText: TextView
    private lateinit var statusText: TextView
    private lateinit var boostButton: Button
    private var gamingMode = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24, 36, 24, 24)
            setBackgroundColor(Color.rgb(15, 15, 18))
        }

        fun label(text: String, size: Float, color: Int): TextView =
            TextView(this).apply {
                this.text = text
                textSize = size
                setTextColor(color)
                gravity = Gravity.CENTER
            }

        val title = label("AI GAME BOOSTER", 25f, Color.WHITE)
        title.setPadding(0, 24, 0, 8)
        root.addView(title)

        val subtitle = label("SMART GAMING CONTROL • DEMO", 12f, Color.rgb(255, 80, 80))
        root.addView(subtitle)

        statusText = label("MODE: NORMAL", 20f, Color.WHITE)
        statusText.setPadding(0, 42, 0, 18)
        root.addView(statusText)

        ramText = label("", 16f, Color.LTGRAY)
        ramText.setPadding(0, 8, 0, 28)
        root.addView(ramText)

        boostButton = Button(this).apply {
            text = "ACTIVATE GAMING MODE"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(190, 25, 35))
            setOnClickListener { toggleGamingMode() }
        }
        root.addView(boostButton, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 58
        ))

        val refreshButton = Button(this).apply {
            text = "REFRESH SYSTEM STATUS"
            setOnClickListener { updateRamInfo() }
        }
        val refreshParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 52
        )
        refreshParams.topMargin = 12
        root.addView(refreshButton, refreshParams)

        val note = label(
            "Note: Android does not allow ordinary apps to force-boost CPU/GPU or clear other apps' memory. This demo provides a gaming-mode toggle and RAM status only.",
            12f, Color.rgb(180, 180, 180)
        )
        note.setPadding(8, 36, 8, 0)
        root.addView(note)

        setContentView(root)
        updateRamInfo()
    }

    private fun toggleGamingMode() {
        gamingMode = !gamingMode
        if (gamingMode) {
            statusText.text = "MODE: GAMING"
            statusText.setTextColor(Color.rgb(255, 80, 80))
            boostButton.text = "DEACTIVATE GAMING MODE"
        } else {
            statusText.text = "MODE: NORMAL"
            statusText.setTextColor(Color.WHITE)
            boostButton.text = "ACTIVATE GAMING MODE"
        }
    }

    private fun updateRamInfo() {
        val manager = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val info = ActivityManager.MemoryInfo()
        manager.getMemoryInfo(info)
        val totalMb = info.totalMem / (1024 * 1024)
        val availableMb = info.availMem / (1024 * 1024)
        ramText.text = "RAM AVAILABLE: ${availableMb} MB\nTOTAL RAM: ${totalMb} MB"
    }
}
